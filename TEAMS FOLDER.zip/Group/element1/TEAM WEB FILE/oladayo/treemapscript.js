let southwestDataSet = 'Southwest-data2.json'

let southwestData

let canvas = d3.select('#canvas')
let tooltip = d3.select('#tooltip')

let drawTreeMap = () => {
    // Create hierachy based on "children"
    let hierarchy = d3.hierarchy(southwestData, (node) => {
        return node['children']
    }).sum((node) => {
        return node['value'] // Assigns value meant fo plotting the size of each rectangle later
    }).sort((node1, node2) => { // Helps in sorting data based on the "value" of each Node. Rectangles will later be drawn in the order of highest magnitude of each node to the lowest
        return node2['value'] - node1['value']
    })

    let createTreeMap = d3.treemap() // Created a method called "treemap"
                            .size([1000, 600]) // size defined based on extent allocated to "canvas" in the style.css file
    
    createTreeMap(hierarchy)

    let southwestTiles = hierarchy.leaves()
    console.log(southwestTiles)
   // Creating the Tiles:
    let block = canvas.selectAll('g')
            .data(southwestTiles)
            .enter()
            .append('g')
                //The area of each tile should correspond to the data-value amount: tiles with a larger data-value should have a bigger area "Set the coordinates of the blocks:"
            .attr('transform', (city) => {
                return 'translate(' + city['x0'] + ', ' + city['y0'] + ')'
            })

    block.append('rect') // Created Rectangles
            .attr('class', 'tile')
            .attr('fill', (city) => { // Assign fill colours for each of the tiles based on "category" used for the tiles
                let category = city['data']['category']
                if(category === 'Remain'){
                    return 'green'
                }else if(category === 'Leave'){
                    return 'coral'
                }
            }).attr('data-name', (city) => { // Add attriutes 'name', 'category', 'value'to each of the rectangular tile
                return city['data']['name']
            }).attr('data-category', (city) => {
                return city['data']['category']
            })
            .attr('data-value', (city) => {
                return city['data']['value']
            })
            //Set the dimensions of the rectangles: interms of width and height
            .attr('width', (city) => {
                return city['x1'] - city['x0']
            })
            .attr('height', (city) => {
                return city['y1'] - city['y0']
            })
            .on('mouseover', (city) => {
                tooltip.transition()
                        .style('visibility', 'visible')

                let Validvotes = city['data']['value'].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")


                tooltip.html(
                    'Valid votes: ' + Validvotes + '<hr />' + city['data']['name']
                )

                tooltip.attr('data-value', city['data']['value'])
            })
            .on('mouseout', (city) => {
                tooltip.transition()
                        .style('visibility', 'hidden')
            })

    block.append('text')
            .text((city) => {
                return city['data']['name']
            })
            .attr('x', 5)
            .attr('y', 20)
}

d3.json(southwestDataSet).then(
    (data, error) => {
        if(error){
            console.log(error)
        } else {
            southwestData = data
            console.log(southwestData)
            drawTreeMap()
        }
    }
)